from distutils.core import setup

setup(name='Flute',
        version='1.0',
        description='A simple tool for running a parallel task pipeline',
        author='Mohammad A.Raji',
        author_email='moa@dragonfli.es',
        scripts=['src/flute']
        )
